The Grand Heirloom - Heritage Door update for the existing Wedora project.
This archive contains the changed source files; it is not a separate standalone app.
Copy frontend/ files into Wedora-main and backend/ files into the existing wedding API project.
Remove the retired frontend files: src/components/invitation/templates/HeirloomTemplate.tsx, heirloom.module.css, HeirloomArt.tsx.
Read frontend/docs/grand-heirloom-heritage-door.md for the Sinhala beginner guide, settings, preview, tests and live database setup.
No environment files, passwords, installed dependencies or customer data are included.
