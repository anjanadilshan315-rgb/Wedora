import type { InvitationViewData } from "./types";
import { DEFAULT_KEEPSAKE } from "./keepsake";
import { DEFAULT_HEIRLOOM } from "./heirloom";

const unsplash = (id: string) => `https://images.unsplash.com/${id}?auto=format&fit=crop&q=80&w=900`;

export const SAMPLE_GALLERY = [
  unsplash("photo-1520854221256-17451cc331bf"),
  unsplash("photo-1519225421980-715cb0215aed"),
  unsplash("photo-1511285560929-80b456fea0bc"),
  unsplash("photo-1606800052052-a08af7148866"),
  unsplash("photo-1583939000148-73599b533d3c"),
];

/** Shown on the template gallery previews (/invite/demo-…). */
export function sampleInvitation(code: string, guestName: string | null): InvitationViewData {
  if (code === "tpl_grand_heirloom") return {
    heirloom: { ...DEFAULT_HEIRLOOM, dressEn: "Elegant celebration attire.", dressSi: "උත්සවයට ගැළපෙන අලංකාර ඇඳුමකින් සැරසී එන්න." },
    guestName,
    brideName: "Anuki", groomName: "Sahan",
    brideParents: "The Perera family", groomParents: "The Jayawardena family",
    bridePhone: null, groomPhone: null,
    weddingDate: "2027-08-21", weddingTime: "10:30", rsvpDeadline: "2027-08-01",
    venueName: "The Golden House · Demo Walawwa", venueAddress: "Fictional heritage courtyard, Kandy, Sri Lanka", mapUrl: null,
    greetingMessage: "Together with our families, we invite you to celebrate our wedding.",
    eventsSchedule: [
      { name: "The Poruwa Ceremony", time: "10:30", venue: "The Golden House · Demo Walawwa", description: "Please join us as we honour tradition and begin our journey together." },
      { name: "An evening to remember", time: "18:30", venue: "The Courtyard · Demo Walawwa", description: "Join us for dinner, music and a celebration under the stars." },
    ],
    coverPhoto: null, bridePhoto: null, groomPhoto: null, gallery: [],
  };
  if (code === "tpl_classic") return {
    keepsake: { ...DEFAULT_KEEPSAKE },
    guestName: guestName ?? "Guest Name",
    groomName: "Kasun", brideName: "Nimali",
    groomParents: null, brideParents: null,
    weddingDate: "2026-12-20", weddingTime: "10:30", rsvpDeadline: "2026-12-01",
    venueName: "The Grand Pavilion", venueAddress: "Galle Road, Colombo 03", mapUrl: null,
    greetingMessage: "Two hearts, one journey.\nWe joyfully invite you to share in our happiness as we begin our new life together.\nYour presence will make our day complete.",
    eventsSchedule: [
      { time: "09:30", name: "Guests arrive", description: "Welcome drink and seating" },
      { time: "10:30", name: "Poruwa ceremony", description: "The couple is wed" },
      { time: "12:00", name: "Wedding lunch", description: "Please stay and dine with us" },
      { time: "14:00", name: "Going away", description: "Send-off for the couple" },
    ],
    coverPhoto: SAMPLE_GALLERY[2], groomPhoto: null, bridePhoto: null,
    gallery: [SAMPLE_GALLERY[0], SAMPLE_GALLERY[2], SAMPLE_GALLERY[3], SAMPLE_GALLERY[4]],
  };
  const traditional = code === "tpl_royal";
  const goldenHour = code === "tpl_golden_hour";
  return {
    guestName: guestName ?? "Guest Name",
    groomName: goldenHour ? "Ravindu" : "Kaveen",
    brideName: goldenHour ? "Sanduni" : "Ishara",
    groomParents: "Mr. & Mrs. Perera",
    brideParents: goldenHour ? "Mr. & Mrs. Fernando" : "Mr. & Mrs. Silva",
    weddingDate: goldenHour ? "2026-12-12" : "2026-11-28",
    weddingTime: goldenHour ? "10:30" : traditional ? "09:15" : "16:30",
    rsvpDeadline: goldenHour ? "2026-12-01" : "2026-11-15",
    venueName: goldenHour ? "Aralya Grand" : traditional ? "Cinnamon Grand" : "The Kingsbury",
    venueAddress: goldenHour ? "Nuwara Eliya, Sri Lanka" : "Colombo 03, Sri Lanka",
    mapUrl: null,
    greetingMessage: goldenHour ? "ඔබගේ පැමිණීමෙන් අපගේ සතුට දෙගුණ වේ. Together with our families, we joyfully invite you to celebrate the beginning of our forever." : "Together with our families, we joyfully invite you to celebrate our wedding.",
    eventsSchedule: goldenHour
      ? [
          { name: "Registration", time: "09:00" },
          { name: "Poruwa Ceremony", time: "10:30" },
          { name: "Reception", time: "18:30" },
        ]
      : traditional
      ? [
          { name: "Welcome of Guests with Magul Bera & Kandyan Dancers", time: "09:15" },
          { name: "Arrival of the Bride & Groom", time: "09:45" },
          { name: "Auspicious Poruwa Ceremony (Nekatha)", time: "10:18" },
          { name: "Traditional Oil Lamp & Cake Cutting", time: "11:30" },
          { name: "Royal Feast & Lunch", time: "12:30" },
          { name: "Going Away Procession", time: "14:30" },
        ]
      : [
          { name: "Welcome Drinks & Guest Arrival", time: "16:00" },
          { name: "Wedding Ceremony", time: "16:30" },
          { name: "Cocktails & Photos", time: "17:30" },
          { name: "Dinner & Reception", time: "19:00" },
          { name: "After Party & Dancing", time: "20:30" },
        ],
    coverPhoto: traditional ? SAMPLE_GALLERY[4] : SAMPLE_GALLERY[2],
    groomPhoto: null,
    bridePhoto: null,
    gallery: SAMPLE_GALLERY,
  };
}
