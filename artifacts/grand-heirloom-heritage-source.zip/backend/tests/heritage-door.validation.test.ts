import { describe, expect, it } from 'vitest';
import { updateInvitationSchema } from '../src/modules/invitations/invitation.validation.js';

describe('Heritage Door settings', () => {
  it.each(['heritage-gold', 'rose-garden', 'emerald-dusk', 'royal-navy', 'sunset-coral', 'ivory-sage'])('saves the %s palette and scene photos', (palette) => {
    const heirloom = { palette, bloom: '#f2b8bd', scenePhotos: { door: '/images/door.jpg', courtyard: 'https://example.com/courtyard.jpg' } };
    expect(updateInvitationSchema.parse({ extraDetails: { heirloom } }).extraDetails?.heirloom).toEqual(heirloom);
  });
  it.each(['javascript:alert(1)', '//example.com/photo.jpg', 'data:text/html,unsafe'])('rejects unsafe scene URLs: %s', (url) => {
    expect(updateInvitationSchema.safeParse({ extraDetails: { heirloom: { scenePhotos: { night: url } } } }).success).toBe(false);
  });
  it('rejects unknown scenes and invalid flower colours', () => {
    expect(updateInvitationSchema.safeParse({ extraDetails: { heirloom: { scenePhotos: { unknown: '/photo.jpg' } } } }).success).toBe(false);
    expect(updateInvitationSchema.safeParse({ extraDetails: { heirloom: { bloom: 'not-a-colour' } } }).success).toBe(false);
  });
});
