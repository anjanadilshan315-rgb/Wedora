import { describe, expect, it } from 'vitest';
import { updateInvitationSchema } from '../src/modules/invitations/invitation.validation.js';

const settings = {
  language: 'si', palette: 'burgundy', font: 'classic',
  main: '#7a1414', accent: '', background: '', envelope: '', musicUrl: '',
  storyEn: 'Our story', storySi: 'අපගේ කතාව', messageSi: 'ඔබට ආරාධනා කරමු', dressEn: '', dressSi: '',
  timeline: [{ year: '2019', titleEn: 'First met', titleSi: 'පළමු හමුවීම', descriptionEn: '', descriptionSi: '' }],
};

describe('invitation design settings', () => {
  it('accepts the dashboard payload and preserves nested Sinhala wording', () => {
    const payload = { extraDetails: { heirloom: settings, keepsake: { theme: 'luxury', accent: '' }, dressCode: 'Formal' } };
    expect(updateInvitationSchema.parse(payload).extraDetails).toEqual(payload.extraDetails);
  });

  it('preserves the existing primitive extra fields', () => {
    expect(updateInvitationSchema.parse({ extraDetails: { dressCode: 'Formal', showGallery: true, tables: 4, note: null } }).extraDetails)
      .toEqual({ dressCode: 'Formal', showGallery: true, tables: 4, note: null });
  });

  it.each([
    { main: 'red;position:fixed' }, { language: 'xx' }, { palette: 'missing' },
    { musicUrl: 'javascript:alert(1)' }, { musicUrl: '//untrusted.example/music.mp3' },
    { timeline: Array(11).fill(settings.timeline[0]) }, { storyEn: 'x'.repeat(4001) },
  ])('rejects invalid design values: %j', (invalid) => {
    expect(updateInvitationSchema.safeParse({ extraDetails: { heirloom: { ...settings, ...invalid } } }).success).toBe(false);
  });

  it('rejects unrelated nested objects and excess extra fields', () => {
    expect(updateInvitationSchema.safeParse({ extraDetails: { arbitrary: { nested: true } } }).success).toBe(false);
    expect(updateInvitationSchema.safeParse({ extraDetails: Object.fromEntries(Array.from({ length: 31 }, (_, i) => [`field${i}`, 'value'])) }).success).toBe(false);
  });
});
