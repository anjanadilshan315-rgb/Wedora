The Grand Heirloom - add Floral Envelope alongside Heritage Door.
This is an update source bundle for the existing Wedora project, not a standalone app.
Copy frontend/ files into Wedora-main and backend/ files into the existing wedding API project.
KEEP every existing Heritage Door component, CSS, artwork, settings, editor and sound file. Do not remove or replace them.
Original preview: /invite/demo-grand-heirloom
New preview: /invite/demo-heirloom-envelope
New template code: tpl_heirloom_envelope. New settings: extraDetails.floralEnvelope.
Read frontend/docs/floral-envelope-beginner-guide.md for the Sinhala beginner guide and SQL registration steps.
The remote database migration has not been run. The SQL only adds the new template row.
No environment files, credentials, dependencies or customer records are included.
