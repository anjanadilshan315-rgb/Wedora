import { z } from 'zod';

const colour = z.string().regex(/^#[0-9a-f]{6}$/i).or(z.literal(''));
const musicUrl = z.string().max(1000).regex(/^(https:\/\/|\/(?!\/))/).or(z.literal(''));

/** Independent settings for the new template; existing Heirloom validation is unchanged. */
export const floralEnvelopeSettingsSchema = z.object({
  language: z.enum(['en', 'si']),
  palette: z.enum(['burgundy', 'navy', 'emerald', 'rose', 'purple', 'teal', 'noir', 'sage', 'peach']),
  font: z.enum(['classic', 'romantic', 'modern']),
  main: colour, accent: colour, background: colour, envelope: colour,
  musicUrl,
  messageSi: z.string().max(2000),
  storyEn: z.string().max(4000), storySi: z.string().max(4000),
  dressEn: z.string().max(2000), dressSi: z.string().max(2000),
  timeline: z.array(z.object({
    year: z.string().max(30), titleEn: z.string().max(100), titleSi: z.string().max(100),
    descriptionEn: z.string().max(1000), descriptionSi: z.string().max(1000),
  })).max(10),
}).partial();
