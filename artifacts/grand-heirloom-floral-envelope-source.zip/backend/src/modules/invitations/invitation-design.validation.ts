import { floralEnvelopeSettingsSchema } from './floral-envelope.validation.js';
import { z } from 'zod';

const colour = z.string().regex(/^#[0-9a-f]{6}$/i).or(z.literal(''));
const musicUrl = z.string().max(1000).regex(/^(https:\/\/|\/(?!\/))/).or(z.literal(''));
const storyMoment = z.object({
  year: z.string().max(30),
  titleEn: z.string().max(100),
  titleSi: z.string().max(100),
  descriptionEn: z.string().max(1000),
  descriptionSi: z.string().max(1000),
});

/** Named nested settings are allowed; other extra fields remain simple values. */
export const invitationExtraDetailsSchema = z.object({
  floralEnvelope: floralEnvelopeSettingsSchema.optional(),
  heirloom: z.object({
    language: z.enum(['en', 'si']),
    palette: z.enum(['burgundy', 'navy', 'emerald', 'rose', 'purple', 'teal', 'noir', 'sage', 'peach', 'heritage-gold', 'rose-garden', 'emerald-dusk', 'royal-navy', 'sunset-coral', 'ivory-sage']),
    font: z.enum(['classic', 'romantic', 'modern']),
    main: colour, accent: colour, background: colour, envelope: colour, bloom: colour,
    scenePhotos: z.partialRecord(z.enum(['door', 'courtyard', 'poruwa', 'house', 'ceremony', 'night']), musicUrl),
    musicUrl,
    storyEn: z.string().max(4000), storySi: z.string().max(4000),
    messageSi: z.string().max(2000),
    dressEn: z.string().max(2000), dressSi: z.string().max(2000),
    timeline: z.array(storyMoment).max(10),
  }).partial().optional(),
  // The existing frontend also sends its Keepsake settings at step four.
  keepsake: z.record(z.string().max(50), z.union([z.string().max(2000), z.number(), z.boolean(), z.null()]))
    .refine((value) => Object.keys(value).length <= 30, 'At most 30 Keepsake fields are allowed')
    .optional(),
}).catchall(z.union([z.string().max(2000), z.number(), z.boolean(), z.null()]))
  .refine((value) => Object.keys(value).length <= 30, 'At most 30 extra fields are allowed');
