import { describe, expect, it } from 'vitest';
import { updateInvitationSchema } from '../src/modules/invitations/invitation.validation.js';

describe('separate Floral Envelope template', () => {
  it.each(['burgundy', 'navy', 'emerald', 'rose', 'purple', 'teal', 'noir', 'sage', 'peach'])('saves %s without changing Heritage Door settings', (palette) => {
    const extraDetails = { heirloom: { palette: 'heritage-gold', scenePhotos: { night: '/night.jpg' } }, floralEnvelope: { palette, language: 'si', messageSi: 'ඔබට ආරාධනා කරමු', main: '#7a1414', musicUrl: '' } };
    expect(updateInvitationSchema.parse({ extraDetails }).extraDetails).toEqual(extraDetails);
  });
  it.each([{ palette: 'heritage-gold' }, { main: 'invalid' }, { musicUrl: 'javascript:alert(1)' }, { timeline: Array(11).fill({ year:'2026',titleEn:'Test',titleSi:'',descriptionEn:'',descriptionSi:'' }) }])('rejects invalid new-template settings: %j', (invalid) => {
    expect(updateInvitationSchema.safeParse({ extraDetails: { floralEnvelope: invalid } }).success).toBe(false);
  });
});
